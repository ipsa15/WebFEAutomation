package methods;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class Driver {

	static WebDriver driver;
	static WebElement object;
	static Logger logger;
	

	public static void launch(String url) {
		try {
			logger = Logger.getLogger("Assignment");
			BasicConfigurator.configure();
			PropertyConfigurator.configure("log\\log4j.properties");
			File f = new File("C:\\Automation\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", f.getAbsolutePath());
			driver = new ChromeDriver();
			HashMap<String, Boolean> pref = new HashMap();
			pref.put("--ignore--certificate-errors", true);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get(url);
			object = driver.findElement(By.xpath("//a[text()='Home ']"));
			if (object != null) {
				logger.info("URL LAUNCHED SUCCESSFULLY");
				object = driver.findElement(By.xpath("//a[text()='Laptops']"));
				if (object != null) {
					object.click();
					logger.info("Laptop tab clicked successfully");
					object = driver.findElement(By.xpath("//a[text()='Sony vaio i5']"));
					if (object != null) {
						object.click();
						logger.info("Laptop model Sony vaio i5 clicked successfully");
						object = driver.findElement(By.xpath("//a[text()='Add to cart']"));
						if (object != null) {
							object.click();
							logger.info("Add to cart option selected successfully");
							Thread.sleep(2000);
							driver.switchTo().alert().accept();
							logger.info("Ok selected successfully");
							Thread.sleep(2000);
							object = driver.findElement(By.xpath("//a[text()='Home ']"));
							if (object != null) {
								object.click();
								logger.info("Home selected successfully");

								object = driver.findElement(By.xpath("//a[text()='Laptops']"));
								if (object != null) {
									object.click();
									logger.info("Laptop tab clicked successfully");
									object = driver.findElement(By.xpath("//a[text()='Dell i7 8gb']"));
									if (object != null) {
										object.click();
										logger.info("Laptop model Dell i7 8gb clicked successfully");
										object = driver.findElement(By.xpath("//a[text()='Add to cart']"));
										if (object != null) {
											object.click();
											logger.info("Add to cart option selected successfully");
											Thread.sleep(2000);
											driver.switchTo().alert().accept();
											logger.info("Ok selected successfully");
											object = driver.findElement(By.xpath("//a[text()='Cart']"));
											if (object != null) {
												object.click();
												logger.info("Cart selected successfully");
												object = driver.findElement(By.xpath(
														"(//td[text()='Dell i7 8gb']//following::a[text()='Delete'])[1]"));
												if (object != null) {
													object.click();
													logger.info("Laptop model Dell i7 8gb model removed successfully");
													Thread.sleep(3000);
													object = driver
															.findElement(By.xpath("//button[text()='Place Order']"));
													if (object != null) {
														object.click();
														logger.info("Place order clicked successfully");
														
													} else {
														logger.info("Unable to click Place order");
													}
												} else {
													logger.info("Uable to remove dell model");
												}
											} else {
												logger.info("Unable to select cart");
											}
										} else {
											logger.info("Unable to select add to cart");
										}

									} else {
										logger.info("Unable to select dell model");
									}
								} else {
									logger.info("Unable to select laptop model");
								}
							} else {
								logger.info("Unable to select home option");
							}

						} else {
							logger.info("Unable to select sony model");
						}
					} else {
						logger.info("Unable to select laptop");
					}
				} else {
					logger.info("URL launched successfully");

				}
			}

		} catch (Exception e) {
                 logger.error(e.getMessage());
		}
	}

	public static void fillDetails() {
	
		object = driver.findElement(By.xpath("//h5[text()='Place order']"));
		if (object != null) {
			logger.info("Form displayed successfully");
			object = driver.findElement(By.xpath("//h5[text()='Place order']//following::label[1]"));
			if (object != null) {
				String expAmt = object.getText();
				if (expAmt != null) {
					logger.info("Amount to be paid captured successfully." + expAmt);
					object = driver.findElement(By.xpath("//label[text()='Name:']//following::input[1]"));
					if (object != null) {
						object.sendKeys("Ipsa");
						logger.info("Name entered successfully");
						object = driver.findElement(By.xpath("//label[text()='Country:']//following::input[1]"));
						if (object != null) {
							object.sendKeys("India");
							logger.info("Country entered successfully");
							object = driver.findElement(By.xpath("//label[text()='City:']//following::input[1]"));
							if (object != null) {
								// Used random string utils here or hard code values can also be added
								object.sendKeys(RandomStringUtils.randomAlphabetic(6));
								logger.info("City entered successfully");
								object = driver
										.findElement(By.xpath("//label[text()='Credit card:']//following::input[1]"));
								if (object != null) {
									object.sendKeys(RandomStringUtils.randomNumeric(16));
									logger.info("Credit card details entered successfully");
									object = driver
											.findElement(By.xpath("//label[text()='Month:']//following::input[1]"));
									if (object != null) {
										object.sendKeys("January");
										logger.info("Month entered successfully");
										object = driver
												.findElement(By.xpath("//label[text()='Year:']//following::input[1]"));
										if (object != null) {
											object.sendKeys("2021");
											logger.info("Year entered successfully");
											object = driver.findElement(By.xpath("//button[text()='Purchase']"));
											if (object != null) {
												object.click();
												logger.info("Purchase button clicked successfully");
												object = driver.findElement(
														By.xpath("//h2[text()='Thank you for your purchase!']"));
												if (object != null) {
													logger.info("Success message displayed successfully");
													object = driver.findElement(
															By.xpath("//p[@class='lead text-muted ']"));
													if (object != null) {
														String purchaseId = object.getText();
														if (purchaseId != null) {
															logger.info(
																"Purchase Id captured successfully :" + purchaseId);
														if (purchaseId.contains(expAmt)) {
															logger.info(
																	"Purchase Id and amount compared successfully :" + purchaseId);
																		object = driver.findElement(
																				By.xpath("//button[text()='OK']"));
																		if (object != null) {
																			object.click();
																			logger.info(
																					"Ok button clicked successfully");
																		} else {
                                                                    logger.info("Unable to click ok");
																		}
																	} else {
																		logger.info("Amount comparison failed");
																	}
																} else {
																	logger.info("Unable to capture purchase details");
																}
															} 
														} else {
															logger.info("Unable to capture success message");
														}
													} else {
														logger.info("Unable to click purchase button");
													}
												} else {
													logger.info("Unable to enter year");
												}
											} else {
												logger.info("Unable to enter month");
											}
										} else {
											logger.info("Unable to enter credit card details");
										}
									} else {
										logger.info("Unable to enter city");
									}

								} else {
									logger.info("Unable to enter country");
								}
							} else {
								logger.info("Unable to enter name");
							}
				} else {
					logger.info("Unable to capture amount");
				}
			} 
		} else {
		logger.info("Unable to view form");
		}
}
}

