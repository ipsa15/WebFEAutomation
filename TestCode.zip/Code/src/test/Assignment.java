package test;

import java.awt.AWTException;
import java.io.File;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import methods.Driver;


class Assignment {
	
	 static WebDriver driver;
	 static WebElement object;
	 static Logger logger;
	static Driver d = new Driver();
	
	public static void main(String[] args) {
		logger = Logger.getLogger("Assignment");
		BasicConfigurator.configure();
		PropertyConfigurator.configure("log\\log4j.properties");
		String url = "https://www.demoblaze.com/index.html ";
		d.launch(url);
		d.fillDetails();
	}
}
